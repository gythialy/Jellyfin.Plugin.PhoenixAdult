#### Key: Supported Search Methods
+ ✅ = **[Enhanced Search](./manualsearch.md#enhanced-search)**. This includes searching by title and/or actor(s), enhanced with date and/or SceneID matching.
+ ✓ = **[Limited Search](./manualsearch.md#limited-search)**. Only title and/or actor can be used, unless otherwise noted.
+ ❌ = **[Exact Match](./manualsearch.md#exact-match)** only. Either using a numerical Scene&nbsp;ID or a Direct&nbsp;URL.

If the site is not listed below &mdash; i.e. the site is not yet supported &mdash; use the instructions for [manual adding](./manualsearch.md#manual-add).

If you're having difficulty finding the SceneID, double-check [PAsiteList.py](../Contents/Code/PAsiteList.py#L183) to make sure you're searching the right website. That code also contains the list of valid [site abbreviations](../Contents/Code/PAsiteList.py#L1548) to use in naming your files.

# All Supported Networks and Sites

+ #### 18 Network | ✓ - **Title or Actor Name**
  - Fit18
  - Thicc18
+ #### 21Naturals | ✅
  - 21EroticAnal
  - 21FootArt
  - 21Naturals
+ #### 21Sextreme | ✅
  - DominatedGirls
  - GrandpasFuckTeens
  - LustyGrandmas
  - TeachMeFisting
  - Zoliboy
+ #### 21Sextury | ✅
  - AnalTeenAngels
  - ButtPlays
  - DeepthroatFrenzy
  - DPFanatics
  - FootsieBabes
  - Gapeland
  - LezCuties
  - PixandVideo
+ #### 5Kporn | ✅
  - 5Kporn
  - 5Kteens
+ #### Abby Winters | ✅
  - Behind the Scenes
  - Best Of
  - Girl Girl
  - Girls and Their Boys
  - Girls In Lingerie At Night
  - Guest Direction
  - Learn How to Get Women
  - Mystery Shoot
  - Nude Girls
  - Nude In Public
  - Podcast
  - Video Masturbation
  - Video Of Myself at Home
+ #### Adult Empire | ✅
+ #### Adult Empire Cash | ✅ - **DVDs not supported**
  - 18 Lust
  - Bizarre Entertainment
  - Black Massive Cocks
  - Brutha's Inc
  - Concoxxxion
  - Conor Coxxx
  - Darkside Entertainment
  - Digital Video Vision
  - Elegant Angel
  - Evasive Angles
  - Forbidden Fruits Films
  - Horny Household
  - Hot Wife Fun
  - Hot Wives Cheating
  - JaysPOV
  - Joanna Angel
  - Jodi West
  - Jonathan Jordan XXX
  - Kaiia Eve
  - Kings of Fetish
  - LeWood
  - Only 3x
  - Pornstar Stroker
  - Reagan Foxx
  - Real Girls Fuck
  - Severe Sex Films
  - SINematica
  - Smut Factor
  - SpankMonster
  - Star Strokers
  - Step House XXX
  - Vouyer Media
  - West Coast Productions
  - Whorecraft VR
+ #### Adult Prime Studios | ✅
  - 4K CFNM
  - Adult Prime
  - Adult Prime Originals
  - BBvideo
  - Beauty and the Senior
  - Bondagettes
  - Bound Men Wanked
  - BrasilBimbos
  - Breed Bus
  - Club Bang Boys
  - Club Castings
  - Club SweetHearts/Seventeen
  - Cockin
  - Color Climax
  - CuckOldest
  - DaringSex HD
  - Digital Desire
  - Dirty Gunther
  - Dirty Hospital
  - Distorded
  - Elegant Raw
  - Evil Playgrounds
  - Family Screw
  - Fan Fuckers
  - Fixxxion
  - Fresh POV
  - Fucking Skinny
  - Gonzo 2000
  - Granddadz
  - GrandMams
  - GrandParentsX
  - Group Banged
  - Group Mams
  - Group Sex Games
  - Hollandsche Passie
  - Interraced
  - Jim Slip
  - Laras Playground
  - Lets Go Bi
  - Mams Casting
  - Manalized
  - Manko 88
  - Massage Sins
  - Mature Van
  - My MILFz
  - My Sexy Kittens
  - OldieX
  - Peep Leek
  - Perfect 18
  - Plumperd
  - Pornstar Classics
  - Pornstars Live
  - Prime Lesbian
  - Raw Euro
  - Red Light Sex Trips
  - Retro Raw
  - Rodox
  - Salsa XXX
  - Sensual Heat
  - Shadow Slaves
  - Sinful Raw
  - Sinful Soft
  - Sinful XXX
  - Southern Sins
  - Submissed
  - Summer Sinners
  - Swhores
  - Teenrs
  - The Pain Files
  - Tranny Bizarre
  - UK Flashers
  - Vintage Classic Porn
  - VR Teens
  - Young Busty
+ #### Adult Time Studios | ✅
  - AdultTime
    - Accidental Gangbang
    - Caught Fapping
    - Couple Swapping
    - Dare We Share
    - Kiss Me Fuck Me
    - Modern Day Sins
    - Oopsie
    - Teen Sneaks
  - FameDigital
    - AllGirlMassage
    - BSkow
    - CumshotOasis
    - DevilsFilm
    - FantasyMassage
    - GirlCore
    - GirlsTryAnal
    - Girlsway
    - GirlswayOriginals
    - GiveMeTeens
    - Joymii
    - MassageParlor
    - MilkingTable
    - ModelTime
    - MommysBoy
    - MommysGirl
    - MomsOnMoms
    - NuruMassage
    - OutOfTheFamily
    - PeterNorth
    - PolyFamilyLife
    - POVMassage
    - PureTaboo
    - RoccoSiffredi
    - SextapeLesbians
    - SilviaSaint
    - SoapyMassage
    - TabooHeat
    - TeraPatrick
    - TouchMyWife
    - TrickySpa
    - WebYoung
    - WeLikeGirls
    - WhiteGhetto
+ #### AllAnalAllTheTime | ✅
+ #### AllHerLuv | ✓
+ #### ALS Angels | ❌ - **Actress name with subject, Date Add**
+ #### Amateur Allure | ✓
+ #### AmourAngels | ❌ - **SceneID**
+ #### AnalVids | ✅
+ #### AngelaWhite | ❌ - **Actor**
+ #### ArchAngel | ✓
+ #### ATK Network | ❌ - **ActressID with Title Search, Date Add**
  - ATKGirlfriends
+ #### Aunt Judys | ✅
  - Aunt Judy's
  - Aunt Judy's XXX
+ #### Aussie Ass | ✅
+ #### Babes Network | ✅
  - Babes
  - Babes Unleashed
  - Black is Better
  - Elegant Anal
  - Office Obsession
  - Stepmom Lessons
+ #### BaDoinkVR Network | ✅
  - 18VR
  - BabeVR
  - BaDoinkVR
  - KinkVR
  - PassthroughVR
  - VRCosplayX
+ #### BAMVisions | ✓
+ #### Bang Bros Network | ✅
  - Ass Parade
  - AvaSpice
  - Back Room Facials
  - Backroom MILF
  - Ball Honeys
  - Bang Bus
  - Bang Casting
  - Bang POV
  - Bang Tryouts
  - BangBros 18
  - BangBros Angels
  - Bangbros Clips
  - BangBros Remastered
  - Big Mouthfuls
  - Big Tit Cream Pie
  - Big Tits Round Asses
  - BlowJob Fridays
  - Blowjob Ninjas
  - Boob Squad
  - Brown Bunnies
  - Can He Score
  - Casting
  - Chongas
  - Colombia Fuck Fest
  - Dirty World Tour
  - Dorm Invasion
  - Facial Fest
  - Fuck Team Five
  - Glory Hole Loads
  - Latina Rampage
  - Living With Anna
  - Magical Feet
  - MILF Lessons
  - Milf Soup
  - MomIsHorny
  - Monsters of Cock
  - Mr Anal
  - Mr CamelToe
  - My Dirty Maid
  - My Life In Brazil
  - Newbie Black
  - Party of 3
  - Pawg
  - Penny Show
  - Porn Star Spa
  - Power Munch
  - Public Bang
  - Slutty White Girls
  - Stepmom Videos
  - Street Ranger
  - Tugjobs
  - Working Latinas
+ #### BangBros Other Sites | ✅
  - Blacks On Moms
  - Filthy Family
  - Mia Khalifa
  - MyGF
  - Sex Selector
  - XXXPawn
+ #### Bang! | ✓ - **Title only**
+ #### Bang! Movies | ✓ - **Title only**
+ #### BBC Paradise | ✅
+ #### Bel Ami Online | ❌ - **SceneID**
+ #### BellaPass | ✓ - **Title only**
  - AleahJasmine
  - AlexisMonroe
  - AvaDawn
  - Babe Archives
  - BellaHD
  - BellaNextDoor
  - Bryci
  - CaliCarter
  - CeceSeptember
  - HD19
  - HunterLeigh
  - Hussie Pass
  - JanaFox
  - JoePerv
  - KatieBanks
  - MonroeLee
  - See Him Fuck
  - TaliaShepard
+ #### Bellesa | ✅ - **Flaresolverr Required**
  - Bellesa Films
  - Bellesa House
+ #### Black PayBack | ✓
+ #### Black Valley Girls | ❌ - **SceneID**
+ #### Blowpass | ✅
  - 1000 Facials
  - ImmoralLive
  - MommyBlowsBest
  - My XXX Pass
  - OnlyTeenBlowjobs
  - Throated
+ #### Blurred Media | ✅
  - Bi Guys Fuck
  - Gay Hoopla
  - Hot Guys Fuck
  - Sugar Daddy Porn
+ #### Bound Honeys | ✓ - **Title only, Date Add**
+ #### Brand New Amateurs | ✓ - **Actor Name**
+ #### Brazzers Network
  ##### Matching type (main): ✓ - **Title only**
  ##### Matching type (alternate): ❌ - **SceneID**
  - Asses In Public
  - Baby Got Boobs
  - Big Butts Like It Big
  - Big Tits at School
  - Big Tits at Work
  - Big Tits in Sports
  - Big Tits in Uniform
  - Big Wet Butts
  - Brazzers Exxtra
  - Busty and Real
  - Busty Z
  - Butts and Blacks
  - CFNM Clothed Female Male Nude
  - Day With A Porn Star
  - Dirty Masseur
  - Doctor Adventures
  - Hot and Mean
  - Hot Chicks Big Asses
  - Milfs Like It Big
  - Mommy Got Boobs
  - Moms in Control
  - Pornstars Like It Big
  - Racks and Blacks
  - Real Wife Stories
  - Shes Gonna Squirt
  - Teens Like It Big
  - Teens Like It Black
  - ZZ Series
+ #### BurningAngel | ✅
+ #### Caramel Cash | ✅
  - Alex Legend
  - Cuckold Wish
  - VrpmvBay
+ #### Caribbeancom | ❌ - **SceneID**
+ #### CherryPimps Network | ✅
  - BCM.XXX
  - Britney Amber
  - Busted
  - Bush
  - Cheese.XXX
  - Cherry Pimps
  - Cherry Spot
  - Confessions.XXX
  - Cucked.XXX
  - Drilled.XXX
  - Femme
  - Fresh
  - Ginger
  - Petite.XXX
  - Taboo (formerly Family.XXX)
  - Wild on Cam
+ #### Clips4Sale | ❌ - **StudioID with Title Search**
+ #### ClubFilly | ❌ - **SceneID, DVDs not supported**
+ #### Colette | ✅
+ #### Couple Fantasies | ✅ - **Date Add**
  - Common Sensual
  - Foxhouse Films
  - Gentle Desire
  - JoyBear
  - Light Southern Cinema
  - Madison Young
  - Maria Beatty
  - Mario Ancewicz
  - Morgana Muses
  - Ninja
  - Petra Joy
  - Pink and Whit Productions
  - Sex School
  - Signe Baumane
  - Spark Erotic
  - The Lifestyle
  - Thousand Faces Films
  - Verso Cinema
+ #### CumBizz | ❌ - **Direct URL**
+ #### CumLouder | ❌ - **Direct URL**
+ #### CzechAV Network | ✓ - **Title only, Date Add**
  - Czech Amateurs
  - Czech Bangbus
  - Czech Bitch
  - Czech Cabins
  - Czech Casting ✅
  - Czech Couples
  - Czech Dungeon
  - Czech Estrogenolit
  - Czech Experiment
  - Czech Fantasy
  - Czech First
  - Czech Game
  - Czech Gangbang
  - Czech Garden Party
  - Czech Harem
  - Czech Home Orgy
  - Czech Lesbians
  - Czech Massage
  - Czech Mega Swingers
  - Czech Orgasm
  - Czech Parties
  - Czech Pawn Shop
  - Czech Pool
  - Czech Sauna
  - Czech Sharking
  - Czech Snooper
  - Czech Solarium
  - Czech Spy
  - Czech Streets
  - Czech Super Models
  - Czech Taxi
  - Czech Toilets
  - Czech Twins
  - Czech Wife Swap
+ #### CzechVR | ✓ - **Actor only**
  - CzechVR
  - CzechVR Casting
  - CzechVR Fetish
+ #### DarkRoomVR | ✓ - **Title only**
+ #### Data18 Porn Database | ✅
  - Empire
  - Scenes
  - Movies
  - Movie Scene
+ #### PornWorld | ✅
  - Cherry Jul
  - DDF Babes
  - DDF Hardcore
  - DDF Network VR
  - DDF Xtreme
  - Eve Angel Official
  - Hairy Twatter
  - PornWorld
  - Sandy's Fantasies
  - Sex Video Casting
+ #### PornWorld Other Sites | ✅
  - 1By-Day
  - DDF Busty
  - Euro Girls on Girls
  - Euro Teen Erotica
  - Hands on Hardcore
  - Hot Legs & Feet
  - House of Taboo
  - Only Blowjob
+ #### Deranged Dollars | ✅
  - Assylum
  - SlaveMouth
+ #### Deviant Hardcore | ✓
+ #### Deviante | ✅
  - Erotic Spice
  - Forgive Me Father
  - Love Her Ass
  - Pretty Dirty Teens
  - Sex Working
+ #### Desperate Amateurs | ✅
+ #### DickDrainers | ✅
+ #### DigitalPlayground | ✅
+ #### Dirty Hard Drive Network | ✅
  - Bang My Hand
  - Dirty Sluts and Studs
  - Girls In Nylon
  - Katie Kox
  - Kiera King
  - Lee Bang XXX
  - Sophie Dee and Friends
  - The Squirt Instructor
+ #### DirtyFlix | ✅ - **Title Only**
  - Make Him Cuckold
  - She Is Nerdy
  - Trick Your GF
  - Tricky Agent
+ #### Dogfart | ✓ - **Date Add**
  - BarbCummings
  - BlackMeatWhiteFeet
  - BlacksOnBlondes
  - BlacksOnBoys
  - BlacksOnCougars
  - CandyMonroe
  - CuckoldSessions
  - CumBang
  - DFXtra
  - DogfarBehindTheScenes
  - GloryHole
  - Gloryhole-Initiations
  - GloryholesAndHandjobs
  - InterracialBlowbang
  - InterracialPickups
  - KatieThomas
  - RuthBlackwell
  - SpringThomas
  - TheMinion
  - WatchingMyDaughterGoBlack
  - WatchingMyMomGoBlack
  - WeFuckBlackGirls
  - WifeWriting
  - ZebraGirls
+ #### Dorcel Club | ✅
+ #### Dorcel Vision | ✓ - **Title only**
+ #### Erito | ✅
+ #### EvilAngel | ✅
+ #### Evolved Fights Network | ✅
  - Evolved Fights
  - Evolved Fights Lesbian Edition
+ #### Explicite Art | ✓ - **Actor only**
+ #### ExploitedX | ✅
  - Backroom Casting Couch
  - BBC Surprise
  - Exploited College Girls
  - Hot Milfs Fuck
+ #### FakeHub | ✅
  - Fake Agent
  - Fake Agent UK
  - Fake Cop
  - Fake Driving School
  - Fake Hospital
  - Fake Hostel
  - Fake Taxi
  - Fakehub Originals
  - Female Agent
  - Female Fake Taxi
  - Public Agent
+ #### FAKings | ✅
  - Ainara's Diary | Diario de Ainara
  - Arnaldo Series
  - Behind FAKings
  - Big Rubber Cocks | Pollazas de Goma
  - Blowjob Lessons | Clases de Mamadas
  - Busted | Cazadas
  - Curvy Girls | Chicas Curvis
  - Exchange Student Girls | Alumnas De Intercambio
  - FAKings Academy | La Escuela de FAKings
  - FAKings Castings | Castings de FAKings
  - FAKings PornStars
  - FAKings Slutwalk | De Paseo con FAKings
  - FAKins Wild Party | Fiestas FAKings
  - First FAKings
  - Free Couples | Parejitas Libres
  - FREE Pussy Day | El Día del Coño GRATIS
  - Fuck Me Fool | Follame Tonto
  - Fuck Them | Follatelos
  - Horsedicks | Rabos de Caballo
  - I'm a Webcam Girl | Soy Webcamer
  - I Sell My Girlfriend | Vendo a mi Novia
  - Innocent 18 | Inocentes 18
  - MILF Club | Club Maduras
  - My First Anal | Mi Primer Anal
  - My First DP | Mi Primera DP
  - NERD BUSTER | Los Cazatolas
  - Newbies Or So They Say | Novatas O Eso Dicen
  - Next Door Girl | Es Tu Vecina
  - Parejas&#46;NET
  - Perverting Couples | Pervirtiendo Parejas
  - Quarantine Stories | Historias de Cuarentena
  - Sick Videos | Videos Enfermos
  - Swingers Life | Vidas Liberales
  - Talk To Them | Hable Con Ellas
  - The Anatomical Sulphate | El Sulfato Anatómico
  - The Naughty Bet | Porno Dolares
  - Trans FAKings
  - Very Voyeur | Muy Voyeur
  - Virtual Reality | FAKingsVR
+ #### FamilyHookups | ✅
+ #### FemdomEmpire / Feminized | ✅
+ #### Femjoy | ✓ - **Model or Title (but not both), Date Add**
+ #### Filthy Kings | ✅
  - Fill Up My Mom
  - Filthy Blowjobs
  - Filthy Massage
  - Filthy Newbies
  - Filthy POV
  - Filthy Taboo
  - FK BTS
  - Hot Girls Raw
  - Its Anal
  - MYLF Seeker
  - Night Creep
+ #### FinishesTheJob | ✅ - **Date Add**
  - ManoJob
  - MrPOV
  - TheDickSuckers
+ #### First Anal Quest | ✓
+ #### Fitting-Room | ❌ - **SceneID, Date Add**
+ #### First Time Videos (FTV) | ✅
  - FTVGirls
  - FTVMilfs
+ #### FuckingAwesome | ✅
+ #### FuelVirtual Network | ✅
  - FuckedHard18
  - MassageGirls18
  - NewGirlPOV
+ #### Full Porn Network | ✓ - **Model Name (will fetch a list of scenes for google-matched model names)**
  - Analized
  - Bad Daddy POV
  - Bad Mommy POV
  - Daughter JOI
  - DTF Sluts
  - James Deen
  - Only Prince
  - Pervert Gallery
  - POV Perverts
  - Twisted Visual
+ #### Gangbang Creampie | ✅
+ #### GASM | ✅
  - Butt Formation
  - Cosplay Babes
  - Filthy and Fisting
  - Fun Movies
  - Harmony Vision
  - Herzog
  - Hot Gold
  - Inflagranti
  - JapanHD
  - Leche69
  - Magma Film
  - MMV Films
  - Paradise Films
  - PornXN
  - Pure XXX Films
  - The Undercover Lover
+ #### Gender X | ✅
+ #### Girl Grind | ✅
+ #### GirlfriendsFilms | ✅
+ #### Girls Rimming | ✅ - **Date Add**
+ #### GirlsOutWest | ✅
+ #### Gloryhole Secrets | ✓ - **Title only** (Title includes actress first name)
+ #### Grooby Network | ✅
  - Black TGirls
  - Bob's TGirls
  - Brazilian Transsexuals
  - Femout.xxx
  - Grooby Girls
  - TGirl Japan
  - TGirl Japan Hardcore
  - TGirls.porn
  - TGirls.xxx
+ #### Heavy on Hotties | ✅
+ #### Hegre | ✓ - **Title only**
+ #### HentaiPros | ✅
+ #### HighTechVR Network | ❌
  - SexBabesVR - **Direct URL**
  - SinsVR - **Direct URL**
  - StasyQVR - **SceneID**
+ #### Holly Randall | ✓
+ #### HotwifeXXX | ✅
+ #### HuCows | ✅
+ #### VIP4K | ✅
  - Black 4k
  - Bride 4k
  - Cuck 4k
  - Daddy 4k
  - Debt 4k
  - Dyke 4k
  - Fist 4k
  - Hunt 4k
  - Ignore 4k
  - Loan 4k
  - Mature 4k
  - Mommy 4k
  - Old 4k
  - Pie 4k
  - Rim 4k
  - Shame 4k
  - Sis
  - Serve 4k
  - Stuck 4k
  - Tutor 4k
+ #### Hush Pass | ✅
+ #### Hustler | ✓ - **Date Add**
+ #### I Kiss Girls | ✅
+ #### Interracial Pass | ✅
+ #### Intersec Network | ✅ - **Actor only**
  - Hardtied
  - Infernal Restraints
  - Insex
  - Pain Toy
  - Real Time Bondage
  - Sensual Pain
  - Sexually Broken
  - Topgrl
+ #### InTheCrack | ✓ - **actress name**
+ #### Jacquie Et Michel TV | ✅
+ #### JavBus (via JavBus - Censored & Uncensored JAV) | ✅ - **SceneID (in form of JAVID)**
+ #### JavDatabase (via JavDatabase) | ✅ - **SceneID (in form of JAVID)**
+ #### JavLibrary (via JavLibrary - Censored JAV Only) | ✅ - **SceneID (in form of JAVID)**
+ #### Jesse Loads Monster Facials | ✅ - **Actor only**
+ #### JulesJordan Network | ✅  **Movies Not Supported**
  - GirlGirl
  - JulesJordan
  - ManuelFerrara
  - SpermSwallowers
  - TheAssFactory
+ #### JVRPorn | ✅ - **Date Add**
+ #### Karups | ✅ - **Actor only**
  - Karups Hometown Amateurs
  - Karups Older Women
  - Karups Private Collection
+ #### Kelly Madison Productions | ✅ - **Episode ID or URL ID** (Date and Summary not always available)
  - Kelly Madison
  - PornFidelity
  - TeenFidelity
+ #### Killergram | ❌ - **SceneID**
+ #### Kin8tengoku | ✅
+ #### Kink Network | ✅
  - 30MinutesofTorment
  - BoundGangBangs
  - BoundGods
  - BoundinPublic
  - BrutalSessions
  - ButtMachineBoys
  - CaptiveMale (Twisted Factory Channel)
  - ChantasBitches (Twisted Factory Channel)
  - DeviceBondage
  - DivineBitches
  - Electrosluts
  - EverythingButt
  - FamiliesTied
  - FetishNetwork
  - FetishNetworkMale
  - Filthy Femdom
  - FootWorship
  - FuckedandBound (Twisted Factory Channel)
  - FuckingMachines
  - HardcoreGangbang
  - Hogtied
  - KinkEvolvedFights
  - KinkEvolvedFightsLesbianEdition
  - KinkFeatures
  - KinkUniversity
  - MenInPain
  - MenOnEdge
  - NakedKombat
  - PublicDisgrace
  - SadisticRope
  - SexAndSubmission
  - SexualDisgracve
  - StraponSquad
  - SubmissiveX
  - TheTrainingOfO
  - TheUpperFloor
  - TSPussyHunters
  - TSSeduction
  - UltimateSurrender
  - WaterBondage
  - WhippedAss
  - WiredPussy
+ #### Kinky Spa | ✓
+ #### Lethal Hardcore | ✅
  - Lethal Hardcore
  - Lethal Hardcore VR
+ #### LetsDoeIt Network | ✅
  - A Girl Knows
  - Bitches Abroad
  - Bums Besuch
  - Bums Buero
  - BumsBus
  - Doe Girls
  - Doe Projects
  - Her Limit
  - Horny Hostel
  - Kinky Inlaws
  - My Naughty Album
  - Porno Academie
  - Quest for Orgasm
  - Relaxxxed
  - Scam Angels
  - The White Boxxx
  - Xchimera
  - XXXShades
+ #### Little Caprice | ✅
  - Buttmuse
  - Caprice Divas
  - NasstyX
  - POVDreams
  - Streetfuck
  - SuperprivateX
  - Wecumtoyou
  - Xpervo
+ #### Look At Her Now | ✅
+ #### LoveHerFilms | ✅
  - LoveHerBoobs
  - LoveHerFeet
  - SheLovesBlack
+ #### Lustomic | ❌ - **SceneID, Date Add**
+ #### LustReality | ✅
+ #### ManyVids | ❌ - **SceneID, Date Add**
+ #### Meana Wolf | ✓
+ #### Melena Maria Rya | ❌ - **SceneID, Date Add**
+ #### Melone Challenge | ✅
+ #### MetadataAPI | ✅
+ #### MetArt Network | ✅
  - ALS Scan
  - Errotica Archives
  - Eternal Desire
  - Love Hairy
  - MetArt
  - MetArtX
  - Rylsky Art
  - SexArt
  - Straplezz
  - Stunning18
  - TheLifeErotic
  - Viv Thomas
+ #### MileHighNetwork | ✅
  - Bi Empire
  - DoghouseDigital
  - RealityJunkies
  - SweetheartVideo
  - SweetSinner
+ #### MileHighNetwork Other Sites | ✅
  - Dilfed
  - FamilySinners
  - Gilfed
  - Milfed
  - Transsensual
+ #### MissaX | ✓
+ #### ModelCentroNetwork | ✅
  - AlettaOceanLive
  - BruceAndMorgan
  - DaniDaniels
  - DeNudeArt
  - DillionNation
  - FallInLovia
  - GetYourKneesDirty
  - GinaGerson
  - JerkOffWithMe
  - Katya-Clover
  - LiluMoon
  - MyLifeInMiami
  - NudeBeauties
  - OfficialChloeToy
  - RomiRain
  - SlutInspection
  - TheLiseySweet
  - VickiValkyrie
  - VinaSkyXXX
  - YummyCouple
+ #### Mofos Network | ✅
  - Busted Babysitters
  - Don't Break Me
  - Ebony Sex Tapes
  - Girls Gone Pink
  - I Know That Girl
  - Latina Sextapes
  - Let's Try Anal
  - LPI
  - Milfs Like It Black
  - Mofos
  - Mofos B Sides
  - Mofos Lab
  - Pervs On Patrol
  - Pornstar Vote
  - Project RV
  - Public Pickups
  - Real Slut Party
  - Share My BF
  - She's A Freak
  - Stranded Teens
  - The Sex Scout
+ #### MomPOV | ✅ - **Title only**
+ #### MormonGirlz | ✓ - **Title or Actor**
+ #### My Pervy Family | ✅
+ #### MyDirtyHobby | ✅
+ #### Mylf Network | ✅ - **Date Add**
  - Anal Mom
  - Ask Your Mother
  - Freeuse MILF
  - Full Of JOI
  - Got Mylf
  - Lone Milf
  - Milf Body
  - Milfty
  - Mom Drips
  - Mom Swap
  - MomShoot
  - Mylf
  - Mylf Classics
  - Mylf Labs
  - Mylf Of The Month
  - Mylf X Bang
  - Mylf X BJ Raw
  - Mylf X CamSoda
  - Mylf X Chad Alva
  - Mylf X Dee Siren
  - Mylf X Elegant Raw
  - Mylf X EvilAngel
  - Mylf X Fucking Awesome
  - Mylf X Hussie Pass
  - Mylf X James Deen
  - Mylf X Joybear
  - Mylf X Karups Older Women
  - Mylf X Lady Fyre
  - Mylf X Little Puck
  - Mylf X Mandy Flores
  - Mylf X Marie McCray
  - Mylf X Manko88
  - Mylf X MariskaX
  - Mylf X Mindi Mink
  - Mylf X Miss Lexa
  - Mylf X Owen Gray
  - Mylf X Paytons Place
  - Mylf X Purgatory X
  - Mylf X SinfulXXX
  - Mylf X SpankMonster
  - Mylf X Steve Holmes
  - Mylf X Teamskeet
  - Mylf X ToughLoveX
  - MylfBlows
  - MylfBoss
  - MylfDom
  - Mylfed
  - Mylfselects
  - Mylfwood
  - New Mylfs
  - PervNana
  - PervPrincipal
  - Secrets
  - StayHomeMilf
  - Tiger Moms
  - Use POV
+ #### Naughty America Network | ✅
  - 2 Chicks Same Time
  - American Daydreams
  - Anal College
  - Asian 1 on 1
  - Ass Masterpiece
  - Big Cock Bully
  - College Sugarbabes
  - Diary of a Milf
  - Diary of a Nanny
  - Dirty Wives Club
  - Fast Times
  - Housewife 1 on 1
  - I have a Wife
  - LA Sluts
  - Latin Adultery
  - Latina Stepmom
  - Lesbian Girl on Girl
  - Live Gym Cam
  - Live Naughty Milf
  - Live Naughty Nurse
  - Live Naughty Secretary
  - Live Naughty Student
  - Live Naughty Teacher
  - Live Party Girl
  - Milf Sugar Babes Classic
  - Mom's Money
  - Mrs. Creampie
  - My Dads Hot Girlfriend
  - My Daughters Hot Friend
  - My First Sex Teacher
  - My Friends Hot Girl
  - My Friends Hot Mom
  - My Girl Loves Anal
  - My Girlfriends Busty Friend
  - My Naughty Latin Maid
  - My Naughty Massage
  - My Sisters Hot Friend
  - My Wife is My Pornstar
  - My Wifes Hot Friend
  - Naughty America
  - Naughty Athletics
  - Naughty Bookworms
  - Naughty Country Girls
  - Naughty Flipside
  - Naughty Office
  - Naughty Rich Girls
  - Naughty Weddings
  - Neighbor Affair
  - Open Family
  - Perfect Fucking Strangers Classic
  - Seduced By A Cougar
  - Show My BF
  - Sleazy Stepdad
  - Slut Stepmom
  - Slut Stepsister
  - SoCal Coeds
  - Teens Love Cream
  - The Passenger
  - Tonights Girlfriend Class
  - Watch Your Mom
  - Watch Your Wife
  - Wives on Vacation
+ #### Naughty America Other Sites | ✓ - **Actor only**
  - Tonights Girlfriend
+ #### NewSensations | ✅ - **Date Add**
+ #### NewSensations Other Sites | ✅
  - Fresh Out of High School
  - Shane Diesel's Banging Babes
  - Tales From the Edge
  - The Romance Series
  - The Tabu Tales
+ #### Nubiles Porn Network | ❌ - **SceneID**
  - Bad Teens Punished
  - Bountyhunter Porn
  - Caught My Coach
  - Cheating Sis
  - Cum Swapping Sis
  - Daddy's Lil Angel
  - Detention Girls
  - Driver XXX
  - Moms Family Secrets
  - Moms Teach Sex
  - My Family Pies
  - Nubiles Casting
  - Nubiles ET
  - Nubiles Porn
  - Nubiles Unscripted
  - Petite Ballerinas Fucked
  - Petite Hd Porn
  - Princess Cum
  - Reality Sis
  - She's Breeding Material
  - Smashed
  - Step Siblings Caught
  - Teacher Fucks Teens
  - Younger Mommy
  #### Mom Comes First | ✅
  #### Mom Lover (Nubiles) Sites | ❌ - **SceneID**
  - Bratty MILF
  - Cheating Mommy
  - Dating My Stepson
  - I'm Not Your Mommmy
  - MILF Coach
  - Mom Lover
  - Mom Swapped
  - Mom Wants Creampie
  - Mom Wants to Breed
  - Mom's Family Secrets
  - Mom's Tight
  - Moms Boy Toy
+ #### Nubiles Other Sites | ❌ - **SceneID**
  - Anilos
  - Bratty Sis
  - Deep Lush
  - Hot Crazy Mess
  - NF Busty
  - Nubilesfilms
  - NubilesNet
  - That Sitcom Show
  - The POV God
+ #### NVG Network | ❌ - **SceneID Only, Date Add, Actor Add (Name1 AND Name2)**
  - Net Video Girls
+ #### OpenlifeNetwork | ✅
  - AbbeyBrooks
  - AshleyFires
  - DevonLee
  - DylanRyder
  - HannaHilton
  - LaneSisters
  - SunnyLeone
+ #### Penthouse Gold | ✅
+ #### PerfectGonzo Network | ✅
  - AllInternal
  - AssTraffic
  - CumForCover
  - PerfectGonzo
  - PrimeCups
  - PurePOV
  - SpermSwap
  - TamedTeens
+ #### PervCity | ✓ - **Title or Actor**
  - Anal Overdose
  - Banging Beauties
  - Chocolate BJs
  - DP Diva
  - Oral Overdose
  - Up Her Asshole
+ #### PJGirls | ✅
+ #### PKJ Media | ✓ - **Title only**
  - MyPOVFam
  - PervertedPOV
  - PetersKingdom
  - RawWhiteMeat
  - SlutsAroundTown
+ #### Playboy Plus | ✅
+ #### PlumperPass | ✅
+ #### Pornbox | ✅
+ #### PornCZ | ✓ - **Title or Actor**
  - Amateri Premium
  - Amateur From Bohemia
  - Boys Fuck MILFs
  - Chloe Lamour
  - Czech Anal Sex
  - Czech Bi Porn
  - Czech Boobs
  - Czech Deviant
  - Czech Escort Girls
  - Czech Executor
  - Czech Gay City
  - Czech Gypsies
  - Czech Hitchhikers
  - Czech Real Dolls
  - Czech Sex Casting
  - Czech Sex Party
  - Czech Shemale
  - Dellia Twins
  - Dick On Trip
  - Fucking Office
  - Fucking Street
  - Girls Take Away
  - Horny Doctor
  - Horny Girls CZ
  - Hunter POV
  - Lady Dee
  - Public From Bohemia
  - Retro Porn CZ
  - Sex In Taxi
  - Sex With Muslims
  - Susan Ayn
  - Teen From Bohemia
  - VR Porn CZ
+ #### Porndoe Premium Network | ✅
  - Badtime Stories
  - Carne Del Mercado
  - Casting Alla Italiana
  - Casting Francais
  - Chicas Loca
  - Crowd Bondage
  - Deutchland Report
  - Exposed Casting
  - Fucked In Traffic
  - Hausfrau Ficken
  - Her Big Ass
  - La Cochonne
  - La Novice
  - Las Folladoras
  - Los Consoladores
  - Narcos X
  - Operacion Limpieza
  - PinUp Sex
  - Porndoepedia
  - Reife Swinger
  - Scambisti Maturi
  - Special Feet Force
  - STG
  - Trans Taboo
  - Transbella
  - Tu Venganza
  - XXX Omas
+ #### PornPortal | ✅
  - 3dxstar Channel PornPortal
  - Anal Channel PornPortal
  - BBW Channel PornPortal
  - Cosplay Channel PornPortal
  - Ebony Channel PornPortal
  - Latina Channel PornPortal
  - Lesbian Channel PornPortal
  - Milf Channel PornPortal
  - RealityGang Channel PornPortal
  - Stepfamily Channel PornPortal
  - Teen Channel PornPortal
  - VR Channel PornPortal
+ #### PornPros Network | ✅ - **Title Only** (Must match the title in the URL after last /)
  - 18 Years Old
  - 40oz Bounce
  - Cock Competition
  - Cruelty Party
  - Cum Disgrace
  - Cumshot Surprise
  - Deep Throat Love
  - Disgraced 18
  - Euro Humpers
  - Freaks Of Boobs
  - Freaks Of Cock
  - GirlCum
  - Jurassic Cock
  - Massage Creep
  - Milf Humiliation
  - Pimp Parade
  - PornPros
  - Real ExGirlfriends
  - Shady Pi
  - Squirt Disgrace
  - TeenBFF
+ #### PornPros Other Sites | ✅ - **Title Only** (Must match the title in the URL after last /)
  - Asians Exploited
  - Baeb
  - BBC POVD
  - BBCPie
  - Bikini Smash
  - Caged Sex
  - CastingCouch-X
  - Creepy Pa
  - Cum4K
  - Double Trouble
  - Exotic4k
  - Exploited Cheerleaders
  - Facials Galore
  - Facials4k
  - FantasyHD
  - Game On
  - Girl Scout Sex
  - GloryHole 4K
  - Holed
  - Kinky Sluts 4K
  - Lubed
  - Mom4k
  - MomCum
  - My Very First Time
  - NannySpy
  - Passion Fuck
  - Passion-HD
  - PornPlus
  - POVD
  - Property Exploits
  - PureMature
  - RV Adventures
  - School of Cock
  - Sexercise
  - Shower 4K
  - SpyFam
  - Squirt Bomb
  - Strippers 4K
  - Throat Creampies
  - Tiny4k
  - Waxxxed
  - WetVR
  - Zoom POV
+ #### PornstarPlatinum | ✅
+ #### POVR | ✓
+ #### PrettyDirty | ✅
+ #### Private | ✅
  - Anal Introductions
  - Blacks on Sluts
  - I Confess Files
  - Mission Ass Possible
  - Private
  - Private Fetish
  - Private MILFs
  - Private Stars
  - Russian Fake Agent
  - Russian Teen Ass
  - Sex on the beach
  - Tight and Teen
+ #### PropertySex | ✅
+ #### Puffy Network | ✓
  - Euro Babe Facials
  - Simply Anal
  - We Like to Suck
  - Wet and Pissy
  - Wet and Puffy
+ #### PureCFNM Network | ❌ - **ActressID with Title Search**
  - AmateurCFNM
  - CFNMGames
  - GirlsAbuseGuys
  - HeyLittleDick
  - LadyVoyeurs
  - PureCFNM
+ #### Putalocura | ✅
+ #### QueenSect | ❌ - **Exact Title Only**
+ #### QueenSnake | ❌ - **Exact Title Only**
+ #### Radical Cash | ✅
  - AltErotic
  - Amazing Films
  - Bemefi
  - Benefit Monkey
  - BJ Raw
  - BlackBullChallenge
  - Cannon Prod
  - Come Inside - **Actor Name Only**
  - Dark Shade
  - Dick HD Daily
  - Dire Desires
  - Divine-DD
  - FreakMobMedia
  - GotFilled
  - Hard Werk
  - Hoby Buchanon
  - Inserted
  - JAV888
  - LegendaryX
  - Lezkey
  - Lucid Flix
  - Nick Marxx
  - Passion POV
  - POV Perv
  - Purity VR
  - Queer Crush
  - Ricky's Room
  - S3XUS
  - Sexy Modern Bull
  - Side Chick
  - Top Web Models
    - 2 Girls 1 Camera
    - Big Gulp Girls
    - Cougar Season
    - Deep Throat Sirens
    - Facials Forever
    - Pounded Petite
    - She's Brand New
  - TwoWebMedia
    - BoppingBabes
    - DownblouseJerk
    - LingerieTales
    - RealBikiniGirls
    - UpskirtJerk
    - WankItNow
  - VRHush
  - XFul
  - Yes Girlz
  - Z Filmz Originals
+ #### Radical Cash Other Sites | ✅
  - Hitzefrei
    - Unleashed
    - CityCheck
    - Milf Hunters
    - Cuff em All
    - fANALarm
    - Fuck On Arrival
    - Family Affairs
    - Patti's Anal
  - Gonzo Living
    - Milf Gonzo
    - Teen Gonzo
  - PurgatoryX
  - ToughLoveX - **Actor Name Only or Title Only**
+ #### Reality Kings Network | ✅
  - 40 Inch Plus
  - 8th Street Latinas
  - Bad Tow Truck
  - Big Naturals
  - Big Tits Boss
  - Bikini Crashers
  - Black GFs
  - Captain Stabbin
  - CFNM Secret
  - Crazy Asian GFs
  - Crazy College GFs
  - Cum Fiesta
  - Cum Girls
  - Dangerous Dongs
  - Dare Dorm
  - Euro Sex Parties
  - Extreme Asses
  - Extreme Naturals
  - First Time Auditions
  - Flower Tucci
  - GF Leaks
  - GF Revenge
  - Girls of Naked
  - Happy Tugs
  - HD Love
  - Horny Birds
  - Hot Bush
  - In the VIP
  - Mike in Brazil
  - Mike's Apartment
  - Milf Hunter
  - Milf Next Door
  - Moms Bang Teens
  - Moms Lick Teens
  - Money Talks
  - Monster Curves
  - No Faces
  - Pure 18
  - Real Orgasms
  - Reckless in Miami
  - RK Prime
  - Round and Brown
  - Saturday Night Latinas
  - See My Wife
  - Sneaky Sex
  - Street BlowJobs
  - Team Squirt
  - Teens Love Huge Cocks
  - Top Shelf Pussy
  - Tranny Surprise
  - VIP Crew
  - We Live Together
  - Wives in Pantyhose
+ #### Reality Kings Other Sites | ✅
  - Lil Humpers
+ #### RealJamVR | ❌ - **Direct URL**
+ #### ReidMyLips | ❌ - **Direct URL**
+ #### Romero Multimedia Network | ✓
  - Deafeated XXX
  - Defeated Sex Fight
  - Freeze
  - Futanari XXX
  - Hentaied
  - Parasited
  - Plants vs Cunts
  - Voodooed
  - Vored
+ #### SapphiX Network | Matching type: ✅
  - Fist Flush
  - Give Me Pink
  - Sapphic Erotica
+ #### Screwbox | ✓
+ #### ScrewMeToo | ✅
+ #### SexLikeReal | ✅
+ #### SexMex | ✅
+ #### SexyHub | ✅
  - Dane Jones
  - Fitness Rooms
  - Girlfriends.xxx
  - Lesbea
  - Massage Rooms
  - MomXXX
+ #### She Will Cheat | ✓
+ #### Sicflics | ✅
+ #### SinsLife | ✓
+ #### SinX | ✓
  - Fully Clothed Pissing
  - Golden Shower Power
  - Pissing in Action
  - Slime Wave
+ #### Spizoo | ✓
  - Cream Her
  - DrDaddyPOV
  - FirstClassPOV
  - Goth Girlfriends
  - IntimateLesbians
  - JessicaJaymesXXX
  - MrLuckyLIFE
  - MrLuckyPOV
  - MrLuckyRAW
  - PornGoesPro
  - PornstarTease
  - RawAttack
  - RealSensual
  - TheStripperExperience
+ #### Step Secrets | ✅ - **Date Add**
+ #### Stepped Up Media | ✅ - **Actor only**
  - AllAnal
  - AnalOnly
  - DirtyAuditions
  - Nymphos
  - Swallowed
  - TrueAnal
+ #### StraponCum | ❌ - **Direct URL**
+ #### Strike3 Network | ✅
  - Blacked
  - BlackedRaw
  - Deeper
  - Milfy
  - Slayed
  - Tushy
  - TushyRaw
  - Vixen
  - Wifey
+ #### Sunny Lane Live | ✅
+ #### Swallow Bay | ❌ - **Direct URL**
+ #### Swallow Salon | ✓
+ #### TeamSkeet Network | ✅ - **Date Add**
  - After Dark
  - Badmilfs
  - BFFs
  - Black Valley Girls
  - BraceFaced
  - Brat Tamer
  - Breeding Material
  - CFNM Teens
  - DadCrush
  - DaughterSwap
  - Dyked
  - ExxxtraSmall
  - FamilyStrokes
  - Foster Tapes
  - Freaky Fembots
  - Freeuse Fantasy
  - Gingerpatch
  - Her Freshman Year
  - Hijab Hookup
  - I Made Porn
  - Innocent High
  - Kissing Sis
  - Little Asians
  - Lust HD
  - My Babysitters Club
  - Mormon Girlz
  - Not My Grandpa
  - Oye Loca
  - PervDoctor
  - PervMom
  - PervTherapy
  - POV Life
  - Rub A Teen
  - Self Desire
  - Sex and Grades
  - She's New
  - Shoplyfter
  - ShoplyfterMylf
  - Sis Loves Me
  - Sis Swap
  - Solo Interviews
  - StayHomePOV
  - StepSiblings
  - TeamSkeet AllStars
  - TeamSkeet Classics
  - TeamSkeet Extras
  - TeamSkeet Features
  - TeamSkeet Labs
  - TeamSkeet Selects
  - TeamSkeet X Avery Black
  - TeamSkeet X BAEB
  - TeamSkeet X Banana Fever
  - TeamSkeet X Bang
  - TeamSkeet X BJ Raw
  - TeamSkeet X Bratty Foot Girls
  - TeamSkeet X BritStudioXXX
  - TeamSkeet X CamSoda
  - TeamSkeet X Club Sweethearts
  - TeamSkeet X Cum Kitchen
  - TeamSkeet X DocTayTay
  - TeamSkeet X Erotique TV Live
  - TeamSkeet X Eva Elfie
  - TeamSkeet X EvilAngel
  - TeamSkeet X Fit18
  - TeamSkeet X Flora Rodgers
  - TeamSkeet X Fucking Awesome
  - TeamSkeet X GrandDadz
  - TeamSkeet X Harmony Films
  - TeamSkeet X Herb Collins
  - TeamSkeet X Impure Desire
  - TeamSkeet X James Deen
  - TeamSkeet X JAV Hub
  - TeamSkeet X Jonathan Jordan
  - TeamSkeet X Joy Bear
  - TeamSkeet X Kriss Kiss
  - TeamSkeet X Layna Landry
  - TeamSkeet X LunaXJames
  - TeamSkeet X Luxury Girl
  - TeamSkeet X Mickey Mod
  - TeamSkeet X Molly RedWolf
  - TeamSkeet X OG
  - TeamSkeet X OZ Fellatio Queens
  - TeamSkeet X POV Perv
  - TeamSkeet X POVGod
  - TeamSkeet X PurgatoryX
  - TeamSkeet X Reislin
  - TeamSkeet X Riley Cyriis
  - TeamSkeet X Screampies
  - TeamSkeet X Slut Inspection
  - TeamSkeet X SpankMonster
  - TeamSkeet X Sweetie Fox
  - TeamSkeet X ToughLoveX
  - TeamSkeet X YoungBusty
  - Teen Curves
  - Teen JOI
  - Teen Pies
  - Teens Do Porn
  - Teens Love Anal
  - Teens Love Black Cocks
  - Teens Love Money
  - Teeny Black
  - The Loft
  - The Real Workout
  - Thickumz
  - This Girl Sucks
  - Tiny Sis
  - Titty Attack
+ #### TeenCoreClub Network | ✅
  - Anal Checkups
  - Analyzed Girls
  - Ass Teen Mouth
  - Bang Teen Pussy
  - Brutal Invasion
  - Cumoholic Teens
  - Defiled 18
  - Double Teamed Teens
  - Dream Teens HD
  - Drilled Chicks
  - Fab Sluts
  - Girls Got Cream
  - Hardcore Youth
  - Jerk-Off Pass
  - Little Hellcat
  - Make Teen Gape
  - Nylon Spunk Junkies
  - Nylon Sweeties
  - Seductive 18
  - She Got Six
  - Spear Teen Pussy
  - Spermatino
  - Teach My Ass
  - Teen Anal Casting
  - Teen Core Club
  - Teen Core Zine
  - Teen Drillers
  - Teens Go Porn
  - Teens Natural Way
  - Teens Try Black
  - Try Teens
  - We Need New Talents
  - White Teens Black Cocks
  - X Core Club
  - Young Throats
+ #### TeenMegaWorld Network | ✅
  - 18 First Sex
  - About Girls Love
  - Anal Angels
  - Anal Beauty
  - ATMovs
  - Beauty 4K
  - BeautyAngels
  - Coeds Reality
  - Creampie Angels
  - Dirty Coach
  - Dirty Doctor
  - el Porno Latino
  - ExGfBox
  - First BGG
  - Fuck Studies
  - Gag N Gape
  - Home Teen Vids
  - Home Toy Teens
  - Lolly Hardcore
  - No Boring
  - Nubile Girls HD
  - NylonsX
  - Old N Young
  - Private Teen Video
  - Raw Couples
  - Solo Teen Girls
  - Squirting Virgin
  - Teen Sex Mania
  - Teen Sex Movs
  - Teen Stars Only
  - Teens 3 Some
  - TMWPOV
  - TmwVRnet
  - Tricky Masseur
  - Watch Me Fucked
  - WOW Orgasms
  - X Angels
+ #### Teeny Taboo | ✅
+ #### The Score Group | ✅
  - 18 Eighteen
  - 50 Plus MILFS
  - 60 Plus MILFS
  - Big Boob Bundle
  - Bootylicious Mag
  - Christy Marks
  - Leg Sex
  - Naughty Mag
  - Porn Mega Load
  - Scoreland
  - Scoreland2
  - ScoreVideos
  - XL Girls
+ #### Thick Cash Network | ✓ - **Actor only, Date Add**
  - Breed Me
  - Ebony Tugs
  - Family Lust
  - MilfAF
  - Over 40 Handjobs
  - Shady Spa
  - Teen Tugs
+ #### TransAngels | ✅
+ #### True Amateurs | ✅
+ #### Twistys | ✅
  - MomKnowsBest
  - TurningTwistys
  - Twistys
  - TwistysHard
  - WhenGirlsPlay
+ #### Ultrafilms | ✓
+ #### Unzip VR | ✅
  - Blow VR
  - VR Bangers
  - VR Conk
  - VRB Gay
  - VRB Trans
+ #### VIPissy | ✓
+ #### VirtualPorn | ✅
+ #### VirtualRealPorn | ❌ - **Direct URL**
+ #### VirtualTaboo | ✓ - **Title only**
+ #### Vivid Network | ✅ - **Title only for DVDs**
+ #### VNA Network | ✅
  - All Anal All The Time
  - Angelina Castro Live
  - Bobbi Eden Live
  - Carmen Valentina
  - Charlee Chase Live
  - Deauxma Live
  - Eva Lin Live
  - Foxxed Up
  - Fucked Feet
  - Gabby Quinteros
  - Girl Girl Mania
  - Its Cleo Live
  - Jelena Jensen
  - Julia Ann Live
  - Kayla Paige Live
  - Kendra James
  - Kimber Lee Live
  - Kink305
  - Maggie Green Live
  - Maxine X
  - Natalia Starr
  - Nikki Benz
  - Nina Kayy
  - Penny Pax Live
  - POV Mania
  - Puma Swede XXX
  - Rachel Storms XXX
  - Rome Major
  - Rubber Doll
  - Samantha Grace
  - Sara Jay
  - Sex My Wife
  - Shanda Fay
  - Siri
  - Sophie Dee Live
  - Sunny Lane Live
  - Tasha Reign
  - Vicky at Home
  - VNA Live
  - Women By Julia Ann
+ #### VogoV | ✓ - **Title only**
+ #### VRAllure | ❌ - Direct URL
+ #### VRHush | ❌ - **Direct URL**
+ #### VRLatina | ✅
+ #### VRP Films | ✅
+ #### WakeUpNFuck | ✓ - **Title or Actor Name**
+ #### Wankz Network | ✓
  - 4K Desire
  - All Interracial
  - Bang My Stepmom
  - Big Tits Like Big Dicks
  - Blow Patrol
  - Bubbly Massage
  - Cougar Sex Club
  - Ebony Internal
  - Escort Trick
  - Exploited 18
  - Handjob Harry
  - I am Eighteen
  - Lesbian Sistas
  - Make Them Gag
  - Matrix Models
  - My Milf Boss
  - Not So Innocent Teens
  - Rap Video Auditions
  - Real Blowjob Auditions
  - Round Juicy Butts
  - Schoolgirl Internal
  - Service Whores
  - Sex For Grades
  - Spoiled Slut
  - Swallow For Cash
  - Tight Holes Big Poles
  - Wank My Wood
  - Wankz TV
  - Whale Tail'n
  - Wild Massage
  - XXX At Work
  - Young Dirty Lesbians
  - Young Sluts Hardcore
+ #### WankzVR Network | ✅
  - MilfVR
  - WankzVR
+ #### Watch4Beauty | ✓ - **Title or Actor Name, Date Add**
+ #### We Are Hairy | ✅
+ #### Why Not Bi | ✅
+ #### Wicked | ✅
+ #### WoodmanCastingX | ✓ - **actress**
+ #### WowNetwork | ✅
  - 18OnlyGirls
  - WowGirls
  - WowPorn
+ #### X-Art | ✅
+ #### XConfessions | ✓
  - LustCinema
+ #### XEmpire | ✅
  - AllBlackX
  - Darkx
  - Eroticax
  - Hardx
  - Lesbianx
+ #### Xev Unleashed | ✅
+ #### Xillimite | ✓ - **Title only, Date Add**
+ #### XVirtual | ✓ - **Title only, Date Add**
+ #### Zero Tolerance | ✅ - **DVDs not supported**

## Adding sites to this list
When this plugin is inevitably updated to add or update a sites' types of searching, you can use the below markdown formatting in a PR to easily add the site in question here

### It is important to go over styling each match type, before proceeding
  + #### ✅
    - `✅`
  + #### ✓ - **Title/Actor only** (Some subtitle or note)
    - Use the subtitle to denote if a site can only use title or actor for searching. No subtitle means both are supported.
    - `✓ - **Title/Actor only** (Some subtitle or note)`
  + #### ❌ - **SceneID/Direct URL** (Some subtitle or note)
    - Use the subtitle to denote if a site uses SceneID or Direct URL.
    - `❌ - **SceneID/Direct URL** (Some subtitle or note)`

### For a single site or studio:
```
+ #### Some Example Site | {✅, ✓, ❌}
```
For example:
```
+ #### XConfessions | ✓
```

### For a parent network or studio (with sub-sites):
```
+ #### Some Example Network | {✅, ✓, ❌}
  - Subsite 1
  - Subsite 2
  - Subsite 3...
```

For example:
```
+ #### Xempire | ✅
  - Darkx
  - Eroticax
  - Hardx
  - Lesbianx
 ```
